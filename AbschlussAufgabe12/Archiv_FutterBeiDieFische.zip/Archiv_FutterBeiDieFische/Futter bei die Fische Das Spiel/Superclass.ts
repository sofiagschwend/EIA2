namespace FutterNemo {
    
    export class Superclass {
        x: number;
        y: number;
        
        constructor() {
            // ohne Inhalt
        }

        setRandomPosition(): void {
            // ohne Inhalt
        }
        
        move(): void {
            // ohne Inhalt
        }
        
        draw(): void {
            // ohne Inhalt
        }
    }
} // namespace zu