var FutterNemo;
(function (FutterNemo) {
    class Superclass {
        constructor() {
            // ohne Inhalt
        }
        setRandomPosition() {
            // ohne Inhalt
        }
        move() {
            // ohne Inhalt
        }
        draw() {
            // ohne Inhalt
        }
    }
    FutterNemo.Superclass = Superclass;
})(FutterNemo || (FutterNemo = {})); // namespace zu
//# sourceMappingURL=Superclass.js.map